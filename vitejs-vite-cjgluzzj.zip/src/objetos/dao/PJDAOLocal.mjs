export default class PJDAO {
  constructor() {
    this.chave = 'pessoasJuridicas';
  }

  toPlain(pj) {
    const end = pj.getEndereco?.();
    const ie = pj.getIE?.();

    return {
      nome: pj.getNome?.() || '',
      email: pj.getEmail?.() || '',
      cnpj: pj.getCNPJ?.() || '',
      endereco: end
        ? {
            cep: end.getCep?.(),
            logradouro: end.getLogradouro?.(),
            bairro: end.getBairro?.(),
            cidade: end.getCidade?.(),
            uf: end.getUf?.(),
            regiao: end.getRegiao?.(),
          }
        : {},
      telefones: (pj.getTelefones?.() || []).map((f) => ({
        ddd: f.getDdd?.(),
        numero: f.getNumero?.(),
      })),
      ie: ie
        ? {
            numero: ie.getNumero?.(),
            estado: ie.getEstado?.(),
            dataRegistro: ie.getDataRegistro?.(),
          }
        : {},
    };
  }

  listar() {
    const dados = localStorage.getItem(this.chave);
    if (!dados) return [];
    try {
      return JSON.parse(dados);
    } catch {
      return [];
    }
  }

  salvar(pj) {
    const lista = this.listar();
    const obj = this.toPlain(pj);
    lista.push(obj);
    localStorage.setItem(this.chave, JSON.stringify(lista));
    return obj;
  }

  excluir(cnpj) {
    const novaLista = this.listar().filter((p) => p.cnpj !== cnpj);
    localStorage.setItem(this.chave, JSON.stringify(novaLista));
  }

  limpar() {
    localStorage.removeItem(this.chave);
  }
}
