import React, { useState } from "react";
import {
  Form,
  Input,
  Button,
  Radio,
  message
} from "antd";
import EnderecoForm from "./EnderecoFormEX.jsx";
import TelefoneList from "./TelefoneListOO.jsx";
import PFForm from "./PFForm.jsx";
import PJForm from "./PJForm.jsx";

import PF from "../../objetos/pessoas/PF.mjs";
import PJ from "../../objetos/pessoas/PJ.mjs";
import Endereco from "../../objetos/pessoas/Endereco.mjs";
import Telefone from "../../objetos/pessoas/Telefone.mjs";
import Titulo from "../../objetos/pessoas/Titulo.mjs";
import IE from "../../objetos/pessoas/IE.mjs";
import PFDAO from "../../objetos/dao/PFDAOLocal.mjs";
import PJDAO from "../../objetos/dao/PJDAOLocal.mjs";

export default function PessoaFormOO() {
  const [form] = Form.useForm();
  const [tipo, setTipo] = useState("PF");

  function onChangeTipo(e) {
    setTipo(e.target.value);
  }

  function onFinish(values) {
    try {
      let pessoa;
      const endVals = values.endereco || {};
      const end = new Endereco();
      end.setCep(endVals.cep);
      end.setLogradouro(endVals.logradouro);
      end.setBairro(endVals.bairro);
      end.setCidade(endVals.cidade);
      end.setUf(endVals.uf);
      end.setRegiao(endVals.regiao);

      if (values.tipo === "PF") {
        const pf = new PF();
        pf.setNome(values.nome);
        pf.setEmail(values.email);
        pf.setCPF(values.cpf);
        pf.setEndereco(end);

        if (values.titulo) {
          const titulo = new Titulo();
          titulo.setNumero(values.titulo.numero);
          titulo.setZona(values.titulo.zona);
          titulo.setSecao(values.titulo.secao);
          pf.setTitulo(titulo);
        }

        if (values.telefones?.length > 0) {
          values.telefones.forEach((tel) => {
            const fone = new Telefone();
            fone.setDdd(tel.ddd);
            fone.setNumero(tel.numero);
            pf.addTelefone(fone);
          });
        }
        pessoa = pf;
      } else {
        const pj = new PJ();
        pj.setNome(values.nome);
        pj.setEmail(values.email);
        pj.setCNPJ(values.cnpj);
        pj.setEndereco(end);

        if (values.ie) {
          const ie = new IE();
          ie.setNumero(values.ie.numero);
          ie.setEstado(values.ie.estado);
          const dr = values.ie.dataRegistro;
          const dataRegistro =
            dr && typeof dr === "object" && typeof dr.format === "function"
              ? dr.format("YYYY-MM-DD")
              : dr || "";
          ie.setDataRegistro(dataRegistro);
          pj.setIE(ie);
        }

        if (values.telefones?.length > 0) {
          values.telefones.forEach((tel) => {
            const fone = new Telefone();
            fone.setDdd(tel.ddd);
            fone.setNumero(tel.numero);
            pj.addTelefone(fone);
          });
        }
        pessoa = pj;
      }

      const dao = values.tipo === "PF" ? new PFDAO() : new PJDAO();
      dao.salvar(pessoa);

      message.success("Pessoa cadastrada com sucesso!");
      form.resetFields();
      setTipo("PF");
    } catch (erro) {
      console.error("Erro ao salvar:", erro);
      message.error("Erro ao salvar registro: " + erro.message);
    }
  }

  return (
    <Form layout="vertical" form={form} onFinish={onFinish} scrollToFirstError>
      <Form.Item label="Tipo de Pessoa" name="tipo" initialValue="PF">
        <Radio.Group onChange={onChangeTipo}>
          <Radio value="PF">Pessoa Física</Radio>
          <Radio value="PJ">Pessoa Jurídica</Radio>
        </Radio.Group>
      </Form.Item>

      <Form.Item
        label="Nome"
        name="nome"
        rules={[{ required: true, message: "Informe o nome!" }]}
      >
        <Input placeholder="Nome completo ou razão social" />
      </Form.Item>

      <Form.Item
        label="Email"
        name="email"
        rules={[
          { required: true, message: "Informe o e-mail!" },
          { type: "email", message: "Formato de e-mail inválido!" }
        ]}
      >
        <Input placeholder="exemplo@email.com" />
      </Form.Item>

      {tipo === "PF" ? (
        <Form.Item
          label="CPF"
          name="cpf"
          rules={[{ required: true, message: "Informe o CPF!" }]}
        >
          <Input placeholder="Somente números" maxLength={11} />
        </Form.Item>
      ) : (
        <Form.Item
          label="CNPJ"
          name="cnpj"
          rules={[{ required: true, message: "Informe o CNPJ!" }]}
        >
          <Input placeholder="Somente números" maxLength={18} />
        </Form.Item>
      )}

      <EnderecoForm />
      <TelefoneList />
      {tipo === "PF" ? <PFForm /> : <PJForm />}

      <Form.Item style={{ marginTop: 24 }}>
        <Button type="primary" htmlType="submit" block size="large">
          Salvar Pessoa
        </Button>
      </Form.Item>
    </Form>
  );
}