import React from "react";
import { Form, Input, Button, Space } from "antd";
import { PlusOutlined, MinusCircleOutlined } from "@ant-design/icons";

export default function TelefoneListOO() {
  return (
    <Form.List name="telefones">
      {(fields, { add, remove }) => (
        <>
          <h4 style={{ marginTop: 16 }}>Telefones</h4>
          {fields.map(({ key, name, ...restField }) => (
            <Space key={key} style={{ display: "flex", marginBottom: 8 }} align="baseline">
              <Form.Item
                {...restField}
                name={[name, "ddd"]}
                rules={[{ required: true, message: "DDD" }]}
                style={{ width: "80px" }}
              >
                <Input placeholder="DDD" maxLength={2} />
              </Form.Item>
              <Form.Item
                {...restField}
                name={[name, "numero"]}
                rules={[{ required: true, message: "Número" }]}
              >
                <Input placeholder="Número de telefone" maxLength={9} />
              </Form.Item>
              <MinusCircleOutlined onClick={() => remove(name)} style={{ color: "#ff4d4f" }} />
            </Space>
          ))}
          <Form.Item>
            <Button type="dashed" onClick={() => add()} block icon={<PlusOutlined />}>
              Adicionar Telefone
            </Button>
          </Form.Item>
        </>
      )}
    </Form.List>
  );
}