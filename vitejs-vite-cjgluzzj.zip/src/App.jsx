import React from 'react';
import { Layout, Typography, Card } from 'antd';
import PessoaFormOO from './components/cadastrapessoa/PessoaFormOO.jsx';

const { Header, Content, Footer } = Layout;
const { Title } = Typography;

export default function App() {
  return (
    <Layout style={{ minHeight: '100vh', background: '#f0f2f5' }}>
      <Header
        style={{
          background: '#001529',
          textAlign: 'center',
          padding: '10px 0',
        }}
      >
        <Title level={3} style={{ color: '#fff', margin: 0 }}>
          Cadastro de Pessoas (OO + Persistência)
        </Title>
      </Header>
      <Content
        style={{
          padding: '24px',
          maxWidth: '800px',
          margin: '0 auto',
          width: '100%',
        }}
      >
        <Card
          style={{
            borderRadius: '8px',
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
          }}
        >
          <PessoaFormOO />
        </Card>
      </Content>
      <Footer style={{ textAlign: 'center' }}>
        JavaScript Orientado a Objetos | ReactJS + Ant Design + DAO
      </Footer>
    </Layout>
  );
}
